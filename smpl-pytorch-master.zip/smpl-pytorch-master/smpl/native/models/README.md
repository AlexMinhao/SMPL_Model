Here copy the .pkl model files.
